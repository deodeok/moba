#import <Foundation/Foundation.h>

//! Project version number for Quick.
FOUNDATION_EXPORT double QuickVersionNumber;

//! Project version string for Quick.
FOUNDATION_EXPORT const unsigned char QuickVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Quick/PublicHeader.h>

#import <Quick/QuickSpec.h>
#import <Quick/QCKDSL.h>
#import <Quick/QuickConfiguration.h>
