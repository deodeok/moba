//
//  StyleConstants.swift
//  MakeSchoolNotes
//
//  Created by Benjamin Encz on 4/29/15.
//  Copyright (c) 2015 Make School. All rights reserved.
//

import UIKit

struct StyleConstants {
  static let defaultBlueColor = UIColor(red: 54/255.0, green: 103/255.0, blue: 138/255.0, alpha: 1.0)
}